$(document).ready(function () {

    //===== BANNER ACTIVE JS

    $('.active-banner').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: false,
    });


    //===== COUNTER UP ACTIVE JS

    $('.counter').counterUp({
        delay: 10,
        time: 2000
    });


    
    //===== TESTIMONIAL ACTIVE JS
    
    $('.testimonial-active').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      prevArrow: '<i class="fas fa-angle-right"></i>',
      nextArrow: '<i class="fas fa-angle-left"></i>',
      autoplay: true,
      autoplaySpeed: 2000,
      speed: 2000,
    });


});
